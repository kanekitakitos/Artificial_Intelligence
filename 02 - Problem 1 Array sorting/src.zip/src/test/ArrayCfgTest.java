package test;

import core.ArrayCfg;
import core.GSolver;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Unit and integration tests for the array sorting problem solver.
 * This class tests the complete flow from Main, using GSolver and ArrayCfg.
 */
public class ArrayCfgTest {

    // To capture System.out
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    // To provide System.in
    private final InputStream originalIn = System.in;

    /**
     * Before each test, redirect System.out to our stream so we can capture the output.
     */
    @BeforeEach
    public void setUpStreams() {
        System.setOut(new PrintStream(outContent));
    }


    public void main (String [] args) throws Exception
    {
        Scanner sc = new Scanner(System.in);
        GSolver gs = new GSolver();
        Iterator<GSolver.State> it =
                gs.solve( new ArrayCfg(sc.nextLine()), new ArrayCfg(sc.nextLine()));

        if (it==null) System.out.println("no solution found");

        else
        {
            while(it.hasNext())
            {
                GSolver.State i = it.next();
                System.out.println(i);
                if (!it.hasNext()) System.out.println((int)i.getK());
            }
        }
        sc.close();
    }

    /**
     * After each test, restore the original System.out and System.in streams.
     */
    @AfterEach
    public void restoreStreams() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }

    /**
     * Helper method to run the main application with a given input string.
     * @param input The string to be provided as standard input, with lines separated by '\n'.
     * @throws Exception if the main method throws an exception.
     */
    private void runAppWithInput(String input) throws Exception {
        ByteArrayInputStream inContent = new ByteArrayInputStream(input.getBytes());
        System.setIn(inContent);
        // We need to use the Main class from the default package
        main(null);
    }

    @Test
    void testAlreadySorted() throws Exception {
        // Arrange
        String input = "1 2 3\n1 2 3\n";
        String expectedOutput = "1 2 3" + System.lineSeparator() +
                "0" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testFromAssignmentSample() throws Exception {
        // Arrange
        String input = "9 7 8\n7 8 9\n";
        String expectedOutput = "9 7 8" + System.lineSeparator() +
                "8 7 9" + System.lineSeparator() +
                "7 8 9" + System.lineSeparator() +
                "22" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testPreferCheapEvenSwap() throws Exception {
        // Arrange
        String input = "4 1 2\n1 2 4\n";
        // The optimal path is (4 1 2) -> swap(4,2 cost 2) -> (2 1 4) -> swap(2,1 cost 11) -> (1 2 4). Total: 13
        String expectedOutput = "4 1 2" + System.lineSeparator() +
                "2 1 4" + System.lineSeparator() +
                "1 2 4" + System.lineSeparator() +
                "13" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    /**
     * Helper to assert only the final state and cost.
     */
    private void assertFinalStateAndCost(String expectedState, int expectedCost) {
        String[] lines = outContent.toString().split(System.lineSeparator());
        String finalState = lines[lines.length - 2];
        int finalCost = Integer.parseInt(lines[lines.length - 1]);
        assertEquals(expectedState, finalState);
        assertEquals(expectedCost, finalCost);
    }

    @Test
    void testExpensiveOddSwap() throws Exception {
        String input = "3 5 1\n1 3 5\n";
        runAppWithInput(input);
        assertFinalStateAndCost("1 3 5", 40);
    }

    @Test
    void testLongerArray() throws Exception
    {
        String input = "4 3 2 1\n1 2 3 4\n";
        runAppWithInput(input);
        assertFinalStateAndCost("1 2 3 4", 22);
    }

    @Test
    void testWithRepeatedNumbers() throws Exception {
        // Arrange
        String input = "2 1 2\n1 2 2\n";
        String expectedOutput = "2 1 2" + System.lineSeparator() +
                "1 2 2" + System.lineSeparator() +
                "11" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testOptimalPathOverGreedyTrap() throws Exception {
        // Arrange
        String input = "2 9 4 7\n7 9 4 2\n";
        // A "greedy" first move would be to swap 2 and 4 (cost 2), leading to state "4 9 2 7".
        // The total cost from there would be 2 (2<>4) + 11 (4<>7) + 2 (2<>4) = 15.
        // The optimal path is a single swap of 2 and 7 (cost 11).
        String expectedOutput = "2 9 4 7" + System.lineSeparator() +
                                "7 9 4 2" + System.lineSeparator() +
                                "11" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testNoSolutionFound() throws Exception {
        // Arrange
        // The goal contains elements not present in the initial state.
        String input = "1 2 3\n4 5 6\n";
        String expectedOutput = "no solution found" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testTwoElementArray() throws Exception {
        // Arrange
        String input = "10 1\n1 10\n";
        String expectedOutput = "10 1" + System.lineSeparator() +
                                "1 10" + System.lineSeparator() +
                                "11" + System.lineSeparator();

        // Act
        runAppWithInput(input);

        // Assert
        assertEquals(expectedOutput, outContent.toString());
    }

    @Test
    void testAllEvenNumbers() throws Exception {
        // Arrange
        String input = "8 6 4 2\n2 4 6 8\n";
        // All swaps should have a cost of 2.
        // A possible path: 8642 -> 2648 (c=2) -> 2468 (c=2). Total=4
        // Let's trace a more likely UCS path:
        // 8642 -> 2648 (c=2)
        // 2648 -> 2468 (c=2) -> Total 4
        runAppWithInput(input);
        assertFinalStateAndCost("2 4 6 8", 4);
    }

    @Test
    void testAllOddNumbers() throws Exception {
        // Arrange
        String input = "5 3 1\n1 3 5\n";
        // All swaps should have a cost of 20.
        runAppWithInput(input);
        assertFinalStateAndCost("1 3 5", 20);
    }
}