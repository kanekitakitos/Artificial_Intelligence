package core;
import java.util.*;


public class GSolver
{
    protected Queue<State> abertos;
    private Map<Ilayout, State> fechados;
    private State actual;
    private Ilayout objective;

    /**
     * Represents a node in the search tree, wrapping a layout and maintaining search-related information.
     * Each state holds a reference to its parent, allowing for path reconstruction, and stores the
     * accumulated cost (`g`) from the initial state to this node.
     */
    public static class State
    {
        private final Ilayout layout;
        private final State father;
        private final double g; // Accumulated cost of the path from the start to this state

        /**
         * Constructs a search node.
         * The accumulated cost `g` is calculated by adding the parent's cost
         * to the cost of the step leading to the current layout.
         * @param l The layout for this state.
         * @param n The parent state in the search tree.
         */
        public State(Ilayout l, State n) {
            layout = l;
            father = n;
            if (father != null)
                g = father.g + layout.getK();
            else g = 0.0;
        }

        @Override
        public String toString() { return layout.toString(); }
        public double getK() { return g; } // Main calls getK() for total cost
        public double getG() { return g; }
        public Ilayout getLayout() { return layout; }
        public State getFather() { return father; }

        @Override
        public int hashCode() { return layout.hashCode(); }

        @Override
        public boolean equals(Object o)
        {
            if (o == null || this.getClass() != o.getClass()) return false;
            State n = (State) o;
            return this.layout.equals(n.layout);
        }
    }

    /**
     * Generates the successor states for a given search node.
     * @param n The parent node.
     * @return A list of `State` objects representing the children.
     */
    final private List<State> successors(State n)
    {
        List<State> sucs = new ArrayList<>();
        List<Ilayout> children = n.layout.children();

        for (Ilayout e : children)
            sucs.add(new State(e, n));
        return sucs;
    }

    /**
     * Executes the search to find the least-cost path from an initial state to a goal state.
     * @param s The initial layout of the problem.
     * @param goal The goal layout of the problem.
     * @return An iterator over the states of the solution path, or null if no solution is found.
     */
    final public Iterator<State> solve(Ilayout s, Ilayout goal)
    {
        objective = goal;
        // PriorityQueue ensures that the state with the lowest 'g' is processed first (Uniform-Cost Search).
        abertos = new PriorityQueue<>(10, Comparator.comparingDouble(State::getG));
        fechados = new HashMap<>();
        abertos.add(new State(s, null));

        while (!abertos.isEmpty())
        {
            actual = abertos.poll();

            if (actual.getLayout().isGoal(objective))
            {
                // Solution found! Reconstruct the solution path.
                LinkedList<State> path = new LinkedList<>();
                State current = actual;
                while (current != null) {
                    path.addFirst(current); // O(1) insertion at the beginning
                    current = current.getFather();
                }
                return path.iterator();
            }

            fechados.put(actual.getLayout(), actual);
            List<State> sucs = successors(actual);

            for (State sucessor : sucs)
            {
                if (!fechados.containsKey(sucessor.getLayout())) {
                    if (!abertos.contains(sucessor)) {
                        abertos.add(sucessor);
                    }
                }
            }
        }
        return null; // No solution found
    }
}
