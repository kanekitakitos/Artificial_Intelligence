package core;

import java.util.List;
/**
 * Defines the contract for a state (or "layout") in a state-space search problem.
 * Any class that represents a state to be used with a search algorithm like {@link BestFirst}
 * must implement this interface. It provides the fundamental operations required for
 * traversing the state space: generating successors, checking for the goal, and determining costs.
 *
 * @author Brandon Mejia
 * @version 2025-09-27
 */
public interface Ilayout
{
    /**
     * Generates all valid successor states (children) from the current state.
     * @return The list of child layouts.
     */
    List<Ilayout> children();

    /**
     * Checks if the current state is the goal state by comparing it to a given layout.
     * @param l The goal layout to compare against.
     * @return `true` if the current layout is the goal, `false` otherwise.
     */
    boolean isGoal(Ilayout l);


    /**
     * @return the cost from the receiver to a successor
     */
    double getK();

    /**
     * Provides a string representation of the layout.
     * This is essential for displaying the state and for debugging.
     * Implementing classes must override this method from {@link Object}.
     * @return A string representation of this layout.
     */
    @Override
    String toString();
}
